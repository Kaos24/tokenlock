# Tokenlock

A Leaving Cert study app for Android. Answer questions to earn tokens, spend tokens to open apps.

## Build
- **On a computer:** open this folder in Android Studio, then Build > Build App Bundle(s) / APK(s) > Build APK(s).
- **Phone only:** see the steps Claude gave you (GitHub Actions builds the APK from tokenlock.zip).

## Change the rules
- Costs, free apps and the 1-minute grace period: `app/src/main/java/com/lcstudy/tokenlock/Config.java`
- Daily goal, bonus odds, how soon missed questions come back: `Store.java`
- Questions: `app/src/main/assets/questions.txt` (format explained at the top of the file)
