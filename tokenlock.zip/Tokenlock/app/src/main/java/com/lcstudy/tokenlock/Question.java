package com.lcstudy.tokenlock;

/** One study question. Keys use a small grammar, see Checker. */
final class Question {
    final int id;
    final char subject; // C = Computer Science, P = Physics, H = Chemistry
    final int difficulty; // 1..3
    final String text;
    final String answer;
    final String keys;

    Question(int id, char subject, int difficulty, String text, String answer, String keys) {
        this.id = id;
        this.subject = subject;
        this.difficulty = Math.max(1, Math.min(3, difficulty));
        this.text = text;
        this.answer = answer;
        this.keys = keys;
    }

    String subjectName() {
        switch (subject) {
            case 'C': return "Computer Science";
            case 'P': return "Physics";
            default: return "Chemistry";
        }
    }

    int color() {
        switch (subject) {
            case 'C': return Ui.CS;
            case 'P': return Ui.PHYSICS;
            default: return Ui.CHEM;
        }
    }

    String dots() {
        StringBuilder b = new StringBuilder();
        for (int i = 1; i <= 3; i++) b.append(i <= difficulty ? '●' : '○');
        return b.toString();
    }
}
