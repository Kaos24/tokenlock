package com.lcstudy.tokenlock;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Covers a blocked app. Pay tokens to open it, earn more, or go home. */
public class GateActivity extends Activity {
    static final String EXTRA_PKG = "pkg";
    static final String EXTRA_COST = "cost";

    private String pkg;
    private int cost;
    private String label;

    private ImageView icon;
    private TextView title, detail, coin;
    private TextView unlock, earn;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        readIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        readIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void readIntent(Intent i) {
        pkg = i.getStringExtra(EXTRA_PKG);
        cost = i.getIntExtra(EXTRA_COST, Config.NORMAL_COST);
        label = pkg;
        Drawable d = null;
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            label = pm.getApplicationLabel(ai).toString();
            d = pm.getApplicationIcon(ai);
        } catch (Exception ignored) {
        }
        if (d != null) icon.setImageDrawable(d);
        refresh();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Ui.BG);
        int pad = Ui.dp(this, 28);
        root.setPadding(pad, Ui.dp(this, 96), pad, pad);

        icon = new ImageView(this);
        int s = Ui.dp(this, 72);
        root.addView(icon, new LinearLayout.LayoutParams(s, s));

        title = Ui.text(this, "", 24, Ui.TEXT, true);
        title.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 20);
        root.addView(title, lp);

        detail = Ui.text(this, "", 16, Ui.MUTED, false);
        detail.setGravity(Gravity.CENTER);
        detail.setLineSpacing(0, 1.2f);
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 8);
        root.addView(detail, lp);

        LinearLayout balance = new LinearLayout(this);
        balance.setGravity(Gravity.CENTER);
        coin = Ui.text(this, "0", 20, Ui.ON_COIN, true);
        coin.setGravity(Gravity.CENTER);
        coin.setBackground(Ui.coin(this));
        int cs = Ui.dp(this, 56);
        balance.addView(coin, new LinearLayout.LayoutParams(cs, cs));
        TextView lbl = Ui.text(this, "  your tokens", 15, Ui.MUTED, false);
        balance.addView(lbl);
        lp = new LinearLayout.LayoutParams(-2, -2);
        lp.topMargin = Ui.dp(this, 32);
        root.addView(balance, lp);

        LinearLayout spacer = new LinearLayout(this);
        root.addView(spacer, new LinearLayout.LayoutParams(-1, 0, 1f));

        unlock = Ui.button(this, "", true);
        unlock.setOnClickListener(v -> unlock());
        root.addView(unlock, new LinearLayout.LayoutParams(-1, -2));

        earn = Ui.button(this, "Earn tokens", false);
        earn.setOnClickListener(v -> startActivity(new Intent(this, QuizActivity.class)));
        lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, 12);
        root.addView(earn, lp);

        TextView home = Ui.text(this, "Go to home screen", 15, Ui.MUTED, false);
        home.setGravity(Gravity.CENTER);
        home.setPadding(0, Ui.dp(this, 16), 0, Ui.dp(this, 8));
        home.setOnClickListener(v -> goHome());
        root.addView(home, new LinearLayout.LayoutParams(-1, -2));

        setContentView(root);
    }

    private void refresh() {
        if (title == null || pkg == null) return;
        int have = Store.get(this).tokens();
        coin.setText(String.valueOf(have));
        String tokenWord = cost == 1 ? "token" : "tokens";
        title.setText(label + " is locked");
        if (have >= cost) {
            detail.setText("Opening it costs " + cost + " " + tokenWord + ".");
            unlock.setText("Open for " + cost + " " + tokenWord);
            Ui.setEnabled(unlock, true);
        } else {
            int need = cost - have;
            detail.setText("Opening it costs " + cost + " " + tokenWord + ". Answer "
                    + need + " more question" + (need == 1 ? "" : "s") + " to open it.");
            unlock.setText("Need " + need + " more");
            Ui.setEnabled(unlock, false);
        }
    }

    private void unlock() {
        Store st = Store.get(this);
        if (!st.spend(cost)) {
            refresh();
            return;
        }
        GuardService.grant(pkg);
        TokenWidget.refresh(this);
        Toast.makeText(this, cost + (cost == 1 ? " token" : " tokens") + " spent. "
                + st.tokens() + " left.", Toast.LENGTH_SHORT).show();
        finish();
        overridePendingTransition(0, 0);
    }

    private void goHome() {
        Intent h = new Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(h);
        finish();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        goHome();
    }
}
