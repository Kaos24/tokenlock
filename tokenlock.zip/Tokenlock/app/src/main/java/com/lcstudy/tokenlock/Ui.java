package com.lcstudy.tokenlock;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

/** Shared colours and small view helpers. */
final class Ui {
    private Ui() {}

    static final int BG = 0xFF141B2D;
    static final int CARD = 0xFF1E2740;
    static final int LINE = 0xFF2C3654;
    static final int TEXT = 0xFFEEF1F7;
    static final int MUTED = 0xFF8C96AD;
    static final int COIN = 0xFFF2B233;
    static final int COIN_DARK = 0xFFC98A12;
    static final int ON_COIN = 0xFF241A00;
    static final int GOOD = 0xFF3CCB7F;
    static final int BAD = 0xFFFF6B5E;
    static final int CS = 0xFF9B8CFF;
    static final int PHYSICS = 0xFF5AA9FF;
    static final int CHEM = 0xFF3DD6B5;

    static int dp(Context c, float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()));
    }

    static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable outline(Context c, int stroke, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(0x00000000);
        d.setStroke(dp(c, 1.5f), stroke);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable coin(Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(COIN);
        d.setStroke(dp(c, 2), COIN_DARK);
        return d;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        return t;
    }

    /** A pill button. primary = gold fill, otherwise outlined. */
    static TextView button(Context c, String label, boolean primary) {
        TextView b = text(c, label, 15, primary ? ON_COIN : TEXT, true);
        b.setGravity(Gravity.CENTER);
        int h = dp(c, 12), w = dp(c, 18);
        b.setPadding(w, h, w, h);
        b.setBackground(primary ? round(c, COIN, 22) : outline(c, LINE, 22));
        b.setClickable(true);
        b.setFocusable(true);
        return b;
    }

    static void setEnabled(TextView b, boolean enabled) {
        b.setEnabled(enabled);
        b.setAlpha(enabled ? 1f : 0.4f);
    }
}
