package com.lcstudy.tokenlock;

import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Marks a typed answer against a question's keys.
 *
 * Keys grammar:
 *   groups separated by ';'  -> every group must match
 *   alternatives separated by ','  -> any one alternative matches the group
 *   a group starting with '!'  -> fails if the answer contains any of its alternatives
 *   '#12.5' or '#3e8~0.01'  -> numeric: any number in the answer within tolerance
 *                              (integers must match exactly unless a tolerance is given)
 *
 * Text matching ignores case and punctuation, allows plurals and small typos.
 */
final class Checker {
    private Checker() {}

    private static final String SUP = "⁰¹²³⁴⁵⁶⁷⁸⁹";
    private static final String SUB = "₀₁₂₃₄₅₆₇₈₉";

    /** Maps super/subscript digits and symbols to plain ones. */
    static String plain(String s) {
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int k = SUP.indexOf(c);
            if (k >= 0) { b.append((char) ('0' + k)); continue; }
            k = SUB.indexOf(c);
            if (k >= 0) { b.append((char) ('0' + k)); continue; }
            switch (c) {
                case '⁺': case '₊': b.append('+'); break;
                case '⁻': case '₋': case '−': case '–': case '—': b.append('-'); break;
                case 'ₙ': b.append('n'); break;
                case '×': case '·': b.append('x'); break;
                default: b.append(c);
            }
        }
        return b.toString();
    }

    static String norm(String s) {
        s = plain(s).toLowerCase(Locale.ROOT).replace("'", "").replace("’", "");
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || c == '.' || c == '-' || c == '+' || c == '/' || c == '^') b.append(c);
            else b.append(' ');
        }
        return b.toString().replaceAll("\\s+", " ").trim();
    }

    static boolean check(String input, String keys) {
        if (input == null) return false;
        String in = norm(input);
        if (in.isEmpty()) return false;
        String compact = in.replace(" ", "").replace("-", "");
        String[] tokens = in.split(" ");
        String[] loose = in.replaceAll("[-+/^]", " ").trim().split("\\s+");
        ArrayList<Double> numbers = numbers(input);

        boolean anyPositive = false;
        for (String rawGroup : keys.split(";")) {
            String group = rawGroup.trim();
            if (group.isEmpty()) continue;
            if (group.startsWith("!")) {
                for (String alt : group.substring(1).split(",")) {
                    String a = norm(alt);
                    if (!a.isEmpty() && (in.contains(a) || compact.contains(a.replace(" ", "").replace("-", "")))) return false;
                }
                continue;
            }
            anyPositive = true;
            boolean ok = false;
            for (String alt : group.split(",")) {
                if (matchAlt(alt.trim(), in, compact, tokens, loose, numbers)) { ok = true; break; }
            }
            if (!ok) return false;
        }
        return anyPositive;
    }

    private static boolean matchAlt(String alt, String in, String compact, String[] tokens, String[] loose,
                                    ArrayList<Double> numbers) {
        if (alt.isEmpty()) return false;
        if (alt.startsWith("#")) return matchNumber(alt.substring(1), numbers);
        String a = norm(alt);
        if (a.isEmpty()) return false;
        if (!a.contains(" ") && a.length() <= 3) {
            // Short keys must be a whole word (so "or" doesn't match "for").
            boolean symbols = a.matches(".*[-+/^].*");
            for (String t : symbols ? tokens : loose) {
                if (t.equals(a) || t.equals(a + "s")) return true;
                if (a.length() == 3 && isAlpha(a) && t.startsWith(a)) return true; // "log" in "log10"
            }
            // Formula-like keys (letters + digits) may sit inside a longer formula, e.g. "2n" in "CnH2n".
            if (a.matches(".*[a-z].*") && a.matches(".*[0-9].*") && in.contains(a)) return true;
            return false;
        }
        if (in.contains(a)) return true;
        if (a.contains(" ") || a.contains("-")) {
            String ca = a.replace(" ", "").replace("-", "");
            if (ca.length() >= 4 && compact.contains(ca)) return true;
            if ((" " + in + " ").contains(" " + a + " ")) return true;
        }
        if (!a.contains(" ") && a.length() >= 5 && isAlpha(a)) {
            int allowed = a.length() >= 8 ? 2 : 1;
            for (String t : tokens) {
                if (Math.abs(t.length() - a.length()) <= allowed && lev(t, a) <= allowed) return true;
                // A one-letter typo inside a longer word, e.g. "ionisaton" for key "ionis"
                if (t.length() > a.length() && lev(t.substring(0, a.length()), a) <= 1) return true;
            }
        }
        return false;
    }

    private static boolean matchNumber(String spec, ArrayList<Double> numbers) {
        double tol = -1;
        int t = spec.indexOf('~');
        if (t >= 0) {
            try { tol = Double.parseDouble(spec.substring(t + 1)); } catch (NumberFormatException ignored) {}
            spec = spec.substring(0, t);
        }
        double v;
        try { v = Double.parseDouble(spec); } catch (NumberFormatException e) { return false; }
        boolean integer = tol < 0 && v == Math.rint(v) && Math.abs(v) < 1e15;
        if (tol < 0) tol = 0.02;
        for (double x : numbers) {
            double ax = Math.abs(x), av = Math.abs(v);
            if (integer) {
                if (Math.abs(ax - av) < 1e-9) return true;
            } else if (Math.abs(ax - av) <= tol * Math.max(av, 1e-300)) {
                return true;
            }
        }
        return false;
    }

    private static final Pattern NUM = Pattern.compile(
            "(-?\\d+(?:\\.\\d+)?|-?\\.\\d+)(?:\\s*(?:x|\\*)\\s*10\\s*\\^\\s*(-?\\d+)|\\s*e\\s*(-?\\d+))?");

    static ArrayList<Double> numbers(String raw) {
        // Turn superscript runs into ^digits so "10⁸" becomes "10^8".
        StringBuilder b = new StringBuilder();
        boolean inSup = false;
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            int k = SUP.indexOf(c);
            boolean supChar = k >= 0 || c == '⁻';
            if (supChar && !inSup) b.append('^');
            inSup = supChar;
            if (k >= 0) b.append((char) ('0' + k));
            else if (c == '⁻') b.append('-');
            else b.append(c);
        }
        String s = plain(b.toString()).toLowerCase(Locale.ROOT);
        // Remove thousands separators: 300,000,000 or 30 000
        String prev;
        do {
            prev = s;
            s = s.replaceAll("(\\d)[, ](\\d{3})(?!\\d)", "$1$2");
        } while (!s.equals(prev));
        ArrayList<Double> out = new ArrayList<>();
        Matcher m = NUM.matcher(s);
        while (m.find()) {
            try {
                double base = Double.parseDouble(m.group(1));
                String exp = m.group(2) != null ? m.group(2) : m.group(3);
                if (exp != null) base = base * Math.pow(10, Integer.parseInt(exp));
                out.add(base);
            } catch (NumberFormatException ignored) {
            }
        }
        return out;
    }

    private static boolean isAlpha(String s) {
        for (int i = 0; i < s.length(); i++) if (!Character.isLetter(s.charAt(i))) return false;
        return true;
    }

    static int lev(String a, String b) {
        int[] prev = new int[b.length() + 1], cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) prev[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] tmp = prev; prev = cur; cur = tmp;
        }
        return prev[b.length()];
    }
}
