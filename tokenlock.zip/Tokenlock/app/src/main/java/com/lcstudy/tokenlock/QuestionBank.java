package com.lcstudy.tokenlock;

import android.content.Context;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/** Loads assets/questions.txt. Line format: SUBJECT|DIFFICULTY|QUESTION|ANSWER|KEYS */
final class QuestionBank {
    private static QuestionBank instance;
    private final ArrayList<Question> all = new ArrayList<>();

    static synchronized QuestionBank get(Context c) {
        if (instance == null) instance = new QuestionBank(c.getApplicationContext());
        return instance;
    }

    private QuestionBank(Context c) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                c.getAssets().open("questions.txt"), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\\|", -1);
                if (p.length < 5 || p[0].isEmpty()) continue;
                int diff;
                try { diff = Integer.parseInt(p[1].trim()); } catch (NumberFormatException e) { diff = 2; }
                all.add(new Question(all.size(), p[0].trim().charAt(0), diff,
                        p[2].trim(), p[3].trim(), p[4].trim()));
            }
        } catch (IOException ignored) {
        }
        if (all.isEmpty()) {
            all.add(new Question(0, 'C', 1, "How many bits are in a byte?", "8", "#8"));
        }
    }

    int size() { return all.size(); }

    Question get(int id) {
        if (id < 0 || id >= all.size()) return all.get(0);
        return all.get(id);
    }

    int count(char subject) {
        int n = 0;
        for (Question q : all) if (q.subject == subject) n++;
        return n;
    }
}
