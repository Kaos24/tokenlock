package com.lcstudy.tokenlock;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

/** The home-screen widget: tokens, streak, today's progress and the current question. */
public class TokenWidget extends AppWidgetProvider {
    static final String ACTION_SKIP = "com.lcstudy.tokenlock.SKIP";

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        m.updateAppWidget(ids, build(c));
    }

    @Override
    public void onReceive(Context c, Intent intent) {
        super.onReceive(c, intent);
        if (ACTION_SKIP.equals(intent.getAction())) {
            Store.get(c).skip(QuestionBank.get(c));
            refresh(c);
        }
    }

    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, TokenWidget.class));
        if (ids == null || ids.length == 0) return;
        m.updateAppWidget(ids, build(c));
    }

    private static RemoteViews build(Context c) {
        Store st = Store.get(c);
        QuestionBank bank = QuestionBank.get(c);
        Question q = bank.get(st.currentId(bank));

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setTextViewText(R.id.w_coin, String.valueOf(st.tokens()));
        v.setTextViewText(R.id.w_streak, "🔥 " + st.streak());
        int today = st.todayCorrect();
        v.setTextViewText(R.id.w_daily, today >= Store.DAILY_GOAL ? "Goal done" : today + "/" + Store.DAILY_GOAL + " today");
        v.setProgressBar(R.id.w_progress, Store.DAILY_GOAL, Math.min(today, Store.DAILY_GOAL), false);
        v.setTextViewText(R.id.w_subject, q.subjectName() + "  " + q.dots());
        v.setTextColor(R.id.w_subject, q.color());
        v.setTextViewText(R.id.w_question, q.text);

        Intent quiz = new Intent(c, QuizActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent open = PendingIntent.getActivity(c, 1, quiz,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.w_root, open);
        v.setOnClickPendingIntent(R.id.w_question, open);
        v.setOnClickPendingIntent(R.id.w_answer, open);

        Intent skip = new Intent(c, TokenWidget.class).setAction(ACTION_SKIP);
        PendingIntent skipPi = PendingIntent.getBroadcast(c, 2, skip,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        v.setOnClickPendingIntent(R.id.w_skip, skipPi);
        return v;
    }
}
