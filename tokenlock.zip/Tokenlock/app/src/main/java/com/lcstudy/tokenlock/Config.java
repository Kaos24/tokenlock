package com.lcstudy.tokenlock;

import android.content.Context;
import android.telecom.TelecomManager;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Which apps cost what. Edit these lists to change the rules. */
final class Config {
    private Config() {}

    static final int NORMAL_COST = 1;
    static final int HIGH_COST = 3;

    /** Once paid for, an app stays open if you leave it for less than this. */
    static final long GRACE_MS = 60_000;

    /** 3 tokens. */
    static final Set<String> HIGH = new HashSet<>(Arrays.asList(
            "com.google.android.youtube",
            "com.instagram.android",
            "com.instagram.lite",
            "com.zhiliaoapp.musically",      // TikTok
            "com.ss.android.ugc.trill",      // TikTok (some regions)
            "com.zhiliaoapp.musically.go"    // TikTok Lite
    ));

    /** Free: your whitelist plus things you must never be locked out of. */
    static final Set<String> FREE = new HashSet<>(Arrays.asList(
            // WhatsApp
            "com.whatsapp", "com.whatsapp.w4b",
            // Phone, calls and contacts
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.phone", "com.android.server.telecom", "com.samsung.android.incallui",
            "com.google.android.contacts", "com.android.contacts", "com.samsung.android.app.contacts",
            // Settings, so you can always change or turn off Tokenlock
            "com.android.settings",
            // Clock, so an alarm can always be switched off
            "com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage",
            // Emergency and safety
            "com.android.emergency", "com.google.android.apps.safetyhub", "com.sec.android.app.safetyassurance"
    ));

    /** System surfaces that are never apps you "open". */
    static final Set<String> SYSTEM = new HashSet<>(Arrays.asList(
            "android", "com.android.systemui",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.android.intentresolver"
    ));

    static int cost(Context c, String pkg) {
        if (FREE.contains(pkg)) return 0;
        try {
            TelecomManager tm = c.getSystemService(TelecomManager.class);
            if (tm != null && pkg.equals(tm.getDefaultDialerPackage())) return 0;
        } catch (Exception ignored) {
        }
        if (HIGH.contains(pkg)) return HIGH_COST;
        return NORMAL_COST;
    }
}
