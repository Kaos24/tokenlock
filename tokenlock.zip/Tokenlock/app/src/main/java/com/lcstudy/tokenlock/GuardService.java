package com.lcstudy.tokenlock;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodInfo;
import android.view.inputmethod.InputMethodManager;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Watches which app comes to the front. If it costs tokens and hasn't been paid for,
 * it covers the app with the block screen. It never reads screen content.
 */
public class GuardService extends AccessibilityService {

    private static GuardService instance;

    private final Set<String> unlocked = new HashSet<>();
    private final Map<String, Long> leftAt = new HashMap<>();
    private final Map<String, Boolean> launchable = new HashMap<>();
    private final Set<String> homes = new HashSet<>();
    private final Set<String> keyboards = new HashSet<>();
    private long systemSetsAt = -1;

    private String current;
    private String gatePkg;
    private long gateAt;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            leaveCurrent();
        }
    };

    static boolean isRunning() { return instance != null; }

    /** Called by the block screen after tokens are paid. */
    static void grant(String pkg) {
        GuardService s = instance;
        if (s == null || pkg == null) return;
        s.unlocked.add(pkg);
        s.leftAt.remove(pkg);
        s.current = pkg;
        s.gatePkg = null;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        refreshSystemSets();
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(screenOff, f, Context.RECEIVER_EXPORTED);
        else registerReceiver(screenOff, f);
    }

    @Override
    public void onDestroy() {
        try { unregisterReceiver(screenOff); } catch (Exception ignored) {}
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (instance == this) instance = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onInterrupt() {}

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence cs = event.getPackageName();
        if (cs == null) return;
        try {
            handle(cs.toString());
        } catch (Exception ignored) {
            // Never let one odd event crash the service.
        }
    }

    private void handle(String pkg) {
        if (pkg.equals(getPackageName())) return;

        long now = SystemClock.elapsedRealtime();
        if (now - systemSetsAt > 10 * 60_000) refreshSystemSets();

        if (homes.contains(pkg)) {
            leaveCurrent();
            return;
        }
        if (Config.SYSTEM.contains(pkg) || keyboards.contains(pkg) || pkg.startsWith("com.android.systemui")) return;
        if (!isLaunchable(pkg)) return; // background helpers and pop-ups without a home-screen icon

        if (!pkg.equals(current)) leaveCurrent();

        int cost = Config.cost(this, pkg);
        if (cost == 0) {
            current = pkg;
            return;
        }

        if (unlocked.contains(pkg)) {
            Long left = leftAt.get(pkg);
            if (left == null || now - left < Config.GRACE_MS) {
                leftAt.remove(pkg);
                current = pkg;
                return;
            }
            unlocked.remove(pkg);
            leftAt.remove(pkg);
        }

        current = pkg;
        if (pkg.equals(gatePkg) && now - gateAt < 800) return;
        gatePkg = pkg;
        gateAt = now;

        Intent i = new Intent(this, GateActivity.class)
                .putExtra(GateActivity.EXTRA_PKG, pkg)
                .putExtra(GateActivity.EXTRA_COST, cost)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(i);
    }

    private void leaveCurrent() {
        if (current != null && unlocked.contains(current)) {
            leftAt.put(current, SystemClock.elapsedRealtime());
        }
        current = null;
    }

    private boolean isLaunchable(String pkg) {
        Boolean cached = launchable.get(pkg);
        if (cached != null) return cached;
        boolean v;
        try {
            v = getPackageManager().getLaunchIntentForPackage(pkg) != null;
        } catch (Exception e) {
            v = false;
        }
        launchable.put(pkg, v);
        return v;
    }

    private void refreshSystemSets() {
        systemSetsAt = SystemClock.elapsedRealtime();
        launchable.clear();
        homes.clear();
        try {
            Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
            List<ResolveInfo> list = getPackageManager().queryIntentActivities(home, PackageManager.MATCH_ALL);
            for (ResolveInfo r : list) homes.add(r.activityInfo.packageName);
        } catch (Exception ignored) {
        }
        keyboards.clear();
        try {
            InputMethodManager imm = getSystemService(InputMethodManager.class);
            if (imm != null) for (InputMethodInfo m : imm.getInputMethodList()) keyboards.add(m.getPackageName());
        } catch (Exception ignored) {
        }
    }
}
