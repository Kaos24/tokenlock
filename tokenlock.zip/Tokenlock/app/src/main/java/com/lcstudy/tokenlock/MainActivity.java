package com.lcstudy.tokenlock;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** Setup and stats. */
public class MainActivity extends Activity {

    private TextView coin, statusTitle, statusBody, turnOn;
    private GridLayout stats;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(build());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        TokenWidget.refresh(this);
    }

    private View build() {
        int pad = Ui.dp(this, 22);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, Ui.dp(this, 40), pad, Ui.dp(this, 40));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = Ui.text(this, "Tokenlock", 30, Ui.TEXT, true);
        head.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        coin = Ui.text(this, "0", 20, Ui.ON_COIN, true);
        coin.setGravity(Gravity.CENTER);
        coin.setBackground(Ui.coin(this));
        int cs = Ui.dp(this, 54);
        head.addView(coin, new LinearLayout.LayoutParams(cs, cs));
        col.addView(head);

        TextView sub = Ui.text(this, "Earn tokens by answering Leaving Cert questions. Spend them to open apps.", 15, Ui.MUTED, false);
        sub.setLineSpacing(0, 1.2f);
        col.addView(sub, top(6));

        // Blocking status
        LinearLayout status = card();
        statusTitle = Ui.text(this, "", 17, Ui.TEXT, true);
        status.addView(statusTitle);
        statusBody = Ui.text(this, "", 14, Ui.MUTED, false);
        statusBody.setLineSpacing(0, 1.25f);
        status.addView(statusBody, top(6));
        turnOn = Ui.button(this, "Turn on app blocking", true);
        turnOn.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        status.addView(turnOn, top(14));
        TextView appInfo = Ui.button(this, "Open App info (for restricted setting)", false);
        appInfo.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + getPackageName()))));
        status.addView(appInfo, top(10));
        col.addView(status, top(22));

        // Actions
        TextView widget = Ui.button(this, "Add widget to home screen", false);
        widget.setOnClickListener(v -> pinWidget());
        col.addView(widget, top(14));
        TextView practice = Ui.button(this, "Answer questions now", true);
        practice.setOnClickListener(v -> startActivity(new Intent(this, QuizActivity.class)));
        col.addView(practice, top(10));

        // Stats
        col.addView(Ui.text(this, "Your progress", 17, Ui.TEXT, true), top(26));
        stats = new GridLayout(this);
        stats.setColumnCount(2);
        col.addView(stats, top(8));

        // Rules
        col.addView(Ui.text(this, "How it works", 17, Ui.TEXT, true), top(26));
        TextView rules = Ui.text(this,
                "Each correct answer earns 1 token. Five in a row earns a bonus token, and some questions are lucky and pay double. "
                        + "Hit " + Store.DAILY_GOAL + " correct in a day for 2 extra tokens.\n\n"
                        + "Most apps cost " + Config.NORMAL_COST + " token to open. YouTube, Instagram and TikTok cost " + Config.HIGH_COST + ". "
                        + "Once you pay, the app stays open while you use it and for a minute after you leave it.\n\n"
                        + "Always free: Phone, Contacts, WhatsApp, Settings, Clock and emergency apps.\n\n"
                        + "Stuck on a question? Tap Show answer. You won't get a token, but it'll come back later so you can learn it.",
                14, Ui.MUTED, false);
        rules.setLineSpacing(0, 1.3f);
        col.addView(rules, top(8));

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.addView(col);
        return sv;
    }

    private void refresh() {
        Store st = Store.get(this);
        QuestionBank bank = QuestionBank.get(this);
        coin.setText(String.valueOf(st.tokens()));

        boolean on = isGuardEnabled();
        statusTitle.setText(on ? "App blocking is on" : "App blocking is off");
        statusTitle.setTextColor(on ? Ui.GOOD : Ui.BAD);
        statusBody.setText(on
                ? "Apps will ask for tokens when you open them."
                : "Tap the button below, find Tokenlock under Installed apps or Downloaded apps, and switch it on.\n\n"
                + "If Android says it's a restricted setting: tap Open App info, tap the ⋮ menu in the top corner, "
                + "choose Allow restricted settings, then try again.");
        turnOn.setVisibility(on ? View.GONE : View.VISIBLE);

        stats.removeAllViews();
        int lvl = st.level();
        addStat("Tokens", String.valueOf(st.tokens()));
        addStat("Level", lvl + "  (" + (st.xp() - Store.levelStart(lvl)) + "/" + (Store.levelStart(lvl + 1) - Store.levelStart(lvl)) + " XP)");
        addStat("Day streak", String.valueOf(st.streak()));
        addStat("Today", st.todayCorrect() + " of " + Store.DAILY_GOAL);
        addStat("Accuracy", st.answered() == 0 ? "–" : st.accuracy() + "%");
        addStat("Best run", String.valueOf(st.bestCombo()));
        addStat("Correct answers", String.valueOf(st.correctCount()));
        addStat("Tokens spent", String.valueOf(st.spent()));
        addStat("Question bank", bank.size() + " questions");
        addStat("Round " + st.round(), st.seenThisRound() + " seen");
    }

    private void addStat(String label, String value) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setPadding(0, Ui.dp(this, 8), Ui.dp(this, 12), Ui.dp(this, 8));
        cell.addView(Ui.text(this, value, 18, Ui.TEXT, true));
        cell.addView(Ui.text(this, label, 12, Ui.MUTED, false));
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        lp.width = 0;
        stats.addView(cell, lp);
    }

    private boolean isGuardEnabled() {
        String s = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (s == null) return false;
        String full = new ComponentName(this, GuardService.class).flattenToString();
        String shortName = new ComponentName(this, GuardService.class).flattenToShortString();
        return s.contains(full) || s.contains(shortName);
    }

    private void pinWidget() {
        AppWidgetManager m = AppWidgetManager.getInstance(this);
        if (m.isRequestPinAppWidgetSupported()) {
            m.requestPinAppWidget(new ComponentName(this, TokenWidget.class), null, null);
        } else {
            Toast.makeText(this, "Long-press your home screen, tap Widgets, and find Tokenlock.", Toast.LENGTH_LONG).show();
        }
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        c.setPadding(p, p, p, p);
        c.setBackground(Ui.round(this, Ui.CARD, 20));
        return c;
    }

    private LinearLayout.LayoutParams top(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = Ui.dp(this, dp);
        return lp;
    }
}
