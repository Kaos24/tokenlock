package com.lcstudy.tokenlock;

import android.content.Context;
import android.content.SharedPreferences;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/** All saved state: tokens, XP, streaks and the no-repeat question order. */
final class Store {
    static final int DAILY_GOAL = 10;
    static final int COMBO_BONUS_EVERY = 5;
    static final int LUCKY_PERCENT = 6;
    static final int REVIEW_GAP = 12;   // a missed question comes back after about this many others
    static final int SKIP_GAP = 60;

    private final SharedPreferences p;
    private static final Random RND = new Random();

    private Store(Context c) {
        p = c.getApplicationContext().getSharedPreferences("tokenlock", Context.MODE_PRIVATE);
    }

    static Store get(Context c) { return new Store(c); }

    static long today() { return LocalDate.now().toEpochDay(); }

    // ---------- tokens ----------
    int tokens() { return p.getInt("tokens", 0); }

    synchronized boolean spend(int n) {
        int t = tokens();
        if (t < n) return false;
        p.edit().putInt("tokens", t - n).putInt("spent", p.getInt("spent", 0) + n).apply();
        return true;
    }

    // ---------- progress ----------
    int xp() { return p.getInt("xp", 0); }
    int level() { return levelFor(xp()); }

    static int levelFor(int xp) {
        int n = 1;
        while (levelStart(n + 1) <= xp) n++;
        return n;
    }

    /** XP needed to reach a level: 0, 100, 300, 600, 1000... */
    static int levelStart(int level) { return 100 * (level - 1) * level / 2; }

    int streak() {
        long last = p.getLong("lastDay", -10);
        return last >= today() - 1 ? p.getInt("streak", 0) : 0;
    }

    int todayCorrect() {
        return p.getLong("todayDay", -1) == today() ? p.getInt("todayCorrect", 0) : 0;
    }

    int combo() { return p.getInt("combo", 0); }
    int answered() { return p.getInt("answered", 0); }
    int correctCount() { return p.getInt("correct", 0); }
    int spent() { return p.getInt("spent", 0); }
    int bestCombo() { return p.getInt("bestCombo", 0); }

    int accuracy() {
        int a = answered();
        return a == 0 ? 0 : Math.round(100f * correctCount() / a);
    }

    static final class Reward {
        int tokens;
        int xp;
        final ArrayList<String> notes = new ArrayList<>();
    }

    /** Records a correct answer and returns what was earned. */
    synchronized Reward correct(Question q, boolean alreadyCounted) {
        Reward r = new Reward();
        long day = today();
        SharedPreferences.Editor e = p.edit();

        int combo = combo() + 1;
        r.tokens = 1;
        r.xp = 10 + (q.difficulty - 1) * 5 + Math.min(combo - 1, 10);

        if (RND.nextInt(100) < LUCKY_PERCENT) {
            r.tokens += 1;
            r.notes.add("Lucky question: double token");
        }
        if (combo % COMBO_BONUS_EVERY == 0) {
            r.tokens += 1;
            r.notes.add(combo + " in a row: bonus token");
        }

        int todayCount = todayCorrect() + 1;
        if (todayCount == DAILY_GOAL) {
            r.tokens += 2;
            r.notes.add("Daily goal done: +2 tokens");
        }

        long last = p.getLong("lastDay", -10);
        int streak = p.getInt("streak", 0);
        if (last != day) {
            streak = (last == day - 1) ? streak + 1 : 1;
            if (streak > 1) r.notes.add(streak + "-day streak");
            e.putInt("streak", streak).putLong("lastDay", day);
        }

        int oldXp = xp();
        int newXp = oldXp + r.xp;
        if (levelFor(newXp) > levelFor(oldXp)) r.notes.add("Level " + levelFor(newXp) + " reached");

        e.putInt("tokens", tokens() + r.tokens)
                .putInt("xp", newXp)
                .putInt("combo", combo)
                .putInt("bestCombo", Math.max(bestCombo(), combo))
                .putLong("todayDay", day)
                .putInt("todayCorrect", todayCount)
                .putInt("correct", correctCount() + 1)
                .putInt("earned", p.getInt("earned", 0) + r.tokens);
        if (!alreadyCounted) e.putInt("answered", answered() + 1);
        e.apply();
        return r;
    }

    void wrongAttempt() { p.edit().putInt("combo", 0).apply(); }

    /** You looked at the answer: no token, and the question comes back soon for review. */
    synchronized void revealed(QuestionBank bank, int id) {
        p.edit().putInt("combo", 0).putInt("answered", answered() + 1).apply();
        requeue(bank, id, REVIEW_GAP);
    }

    // ---------- question order (shuffle bag, so nothing repeats until you've seen them all) ----------
    synchronized int currentId(QuestionBank bank) {
        int id = p.getInt("cur", -1);
        if (id < 0 || id >= bank.size() || p.getInt("bagSig", -1) != bank.size()) id = advance(bank);
        return id;
    }

    synchronized int advance(QuestionBank bank) {
        ArrayList<Integer> bag = loadBag(bank);
        int pos = p.getInt("bagPos", 0);
        if (pos >= bag.size()) {
            bag = shuffled(bank.size());
            pos = 0;
            p.edit().putInt("round", p.getInt("round", 0) + 1).apply();
        }
        int id = bag.get(pos);
        saveBag(bag, pos + 1, bank.size());
        p.edit().putInt("cur", id).apply();
        return id;
    }

    synchronized void skip(QuestionBank bank) {
        int id = currentId(bank);
        requeue(bank, id, SKIP_GAP);
        advance(bank);
    }

    int seenThisRound() { return p.getInt("bagPos", 0); }
    int round() { return p.getInt("round", 0) + 1; }

    private void requeue(QuestionBank bank, int id, int gap) {
        ArrayList<Integer> bag = loadBag(bank);
        int pos = p.getInt("bagPos", 0);
        int at = Math.min(pos + gap, bag.size());
        bag.add(at, id);
        saveBag(bag, pos, bank.size());
    }

    private ArrayList<Integer> loadBag(QuestionBank bank) {
        if (p.getInt("bagSig", -1) != bank.size()) {
            ArrayList<Integer> fresh = shuffled(bank.size());
            saveBag(fresh, 0, bank.size());
            return fresh;
        }
        ArrayList<Integer> bag = new ArrayList<>();
        String s = p.getString("bag", "");
        if (!s.isEmpty()) {
            for (String part : s.split(",")) {
                try {
                    int v = Integer.parseInt(part);
                    if (v >= 0 && v < bank.size()) bag.add(v);
                } catch (NumberFormatException ignored) {
                }
            }
        }
        if (bag.isEmpty()) {
            bag = shuffled(bank.size());
            saveBag(bag, 0, bank.size());
        }
        return bag;
    }

    private void saveBag(ArrayList<Integer> bag, int pos, int sig) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < bag.size(); i++) {
            if (i > 0) b.append(',');
            b.append(bag.get(i));
        }
        p.edit().putString("bag", b.toString()).putInt("bagPos", pos).putInt("bagSig", sig).apply();
    }

    private static ArrayList<Integer> shuffled(int n) {
        ArrayList<Integer> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) list.add(i);
        Collections.shuffle(list, RND);
        return list;
    }
}
